<?php
namespace Tests\Feature;
use App\Models\Election;
use App\Models\ElectionResult;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use Tests\TestCase;

class AdminImportTest extends TestCase
{
    use RefreshDatabase;

    private function payload(Election $election, string $csv): array
    {
        return [
            'file' => UploadedFile::fake()->createWithContent('t.csv', $csv),
            'election_id' => $election->id,
            'dataset_type' => 'REAL',
        ];
    }

    private function election(): Election
    {
        return Election::create(['year' => 2023, 'type' => 'Presidential', 'state' => 'Bauchi', 'name' => '2023 Presidential Election - Bauchi', 'status' => 'ACTIVE']);
    }

    public function test_guest_is_redirected_to_login(): void { $this->get('/admin/import')->assertRedirect('/login'); }

    public function test_non_admin_is_forbidden(): void
    {
        $this->actingAs(User::factory()->create(['role' => 'OBSERVER']))->get('/admin/import')->assertForbidden();
    }

    public function test_successful_import(): void
    {
        $csv = "state,polling_unit_code,polling_unit_name,lga,ward,accredited_voters,apc,pdp,rejected_votes,total_votes\nS,T1,PU 1,A,W,500,200,200,10,410\nS,T2,PU 2,A,W,500,300,300,10,610\n";
        $this->actingAs(User::factory()->create(['role' => 'ADMIN']))
            ->post('/admin/import', $this->payload($this->election(), $csv))->assertRedirect('/admin/import');
        $this->assertSame(2, ElectionResult::count());
        $this->assertSame(1, ElectionResult::where('validation_status', 'INVALID')->count());
    }

    public function test_invalid_csv_is_rejected(): void
    {
        $this->actingAs(User::factory()->create(['role' => 'ADMIN']))
            ->post('/admin/import', $this->payload($this->election(), "foo,bar\n1,2\n"))->assertSessionHasErrors('file');
        $this->assertSame(0, ElectionResult::count());
    }
}

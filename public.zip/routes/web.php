<?php

use App\Http\Controllers\Admin\DashboardController as AdminDashboard;
use App\Http\Controllers\Admin\ImportController;
use App\Http\Controllers\Admin\ReviewController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\ResultController;
use App\Http\Middleware\EnsureAdmin;
use Illuminate\Support\Facades\Route;

// Public (read-only)
Route::get('/', [DashboardController::class, 'index'])->name('home');
Route::get('/results', [ResultController::class, 'index'])->name('results.index');
Route::get('/results/{result}', [ResultController::class, 'show'])->name('results.show');

// Breeze expects a 'dashboard' route after login
Route::get('/dashboard', fn () => redirect()->route('admin.dashboard'))->middleware('auth')->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

// Administrator
Route::middleware(['auth', EnsureAdmin::class])->prefix('admin')->name('admin.')->group(function () {
    Route::get('/', [AdminDashboard::class, 'index'])->name('dashboard');
    Route::get('/import', [ImportController::class, 'index'])->name('import');
    Route::post('/import', [ImportController::class, 'store'])->name('import.store');
    Route::get('/results', [ReviewController::class, 'results'])->name('results');
    Route::get('/flagged', [ReviewController::class, 'flagged'])->name('flagged');
    Route::get('/results/{result}', [ReviewController::class, 'show'])->name('results.show');
    Route::post('/results/{result}/review', [ReviewController::class, 'review'])->name('results.review');
    Route::get('/audit-logs', [AdminDashboard::class, 'auditLogs'])->name('audit');
    Route::post('elections/{election}/archive', [AdminElection::class, 'archive'])->name('elections.archive');
});

require __DIR__ . '/auth.php';

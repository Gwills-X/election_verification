<?php
return [
    'types' => ['Presidential', 'Governorship', 'Senatorial', 'House of Representatives', 'State Assembly'],
];

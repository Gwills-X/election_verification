import { Link, usePage } from "@inertiajs/react";
export default function PublicLayout({ children }) {
    const { auth } = usePage().props;
    return (
        <div className="flex min-h-screen flex-col bg-gray-50 text-slate-900">
            <header className="bg-slate-900 text-white">
                <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-4">
                    <Link href={route("home")} className="font-semibold">
                        Election Result Verification
                    </Link>
                    <nav className="flex gap-5 text-sm">
                        <Link
                            href={route("home")}
                            className="hover:text-slate-300"
                        >
                            Home
                        </Link>
                        <Link
                            href={route("verify.index")}
                            className="hover:text-slate-300"
                        >
                            Verify a Result
                        </Link>
                        <Link
                            href={route("results.index")}
                            className="hover:text-slate-300"
                        >
                            Browse Results
                        </Link>
                        {auth?.user ? (
                            <Link
                                href={route("dashboard")}
                                className="hover:text-slate-300"
                            >
                                Dashboard
                            </Link>
                        ) : (
                            <Link
                                href={route("login")}
                                className="hover:text-slate-300"
                            >
                                Staff Login
                            </Link>
                        )}
                    </nav>
                </div>
            </header>
            <main className="mx-auto w-full max-w-6xl flex-1 px-4 py-8">
                {children}
            </main>
            <footer className="border-t bg-white py-4 text-center text-xs text-gray-500">
                This system organises election information and identifies data
                inconsistencies. It does not determine whether an election was
                free, fair, fraudulent or otherwise legitimate.
            </footer>
        </div>
    );
}

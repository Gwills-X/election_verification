import { Link, router, usePage } from "@inertiajs/react";

const NAV = {
    ADMIN: [
        ["admin.dashboard", "Dashboard"],
        ["admin.elections.index", "Elections"],
        ["admin.import", "Import Data"],
        ["admin.results", "All Results"],
        ["admin.flagged", "Flagged Records"],
        ["admin.reports.index", "Reports"],
        ["admin.users.index", "Users"],
        ["admin.audit", "Audit Logs"],
    ],
    ELECTION_OFFICER: [
        ["officer.dashboard", "Dashboard"],
        ["officer.elections", "My Elections"],
        ["officer.results", "Results"],
        ["officer.queue", "Review Queue"],
        ["officer.reports.index", "Reports"],
    ],
    OBSERVER: [
        ["observer.dashboard", "Dashboard"],
        ["observer.elections", "Elections"],
        ["observer.results", "Results"],
    ],
};

const isActive = (name) => {
    try {
        return (
            route().current(name) ||
            route().current(name.replace(/\.index$/, ".*"))
        );
    } catch {
        return false;
    }
};

export default function AppLayout({ title, children }) {
    const { auth, flash } = usePage().props;
    const user = auth?.user;
    const logout = (e) => {
        e.preventDefault();
        router.post(route("logout"));
    };
    return (
        <div className="flex min-h-screen bg-gray-100">
            <aside className="flex w-64 flex-col bg-slate-900 text-slate-300">
                <div className="px-6 py-5">
                    <Link
                        href={route("home")}
                        className="text-lg font-bold text-white"
                    >
                        Election Verification
                    </Link>
                    <p className="mt-1 text-xs text-slate-400">
                        Management &amp; Public Verification
                    </p>
                </div>
                <nav className="flex-1 space-y-1 px-3 py-2">
                    {(NAV[user?.role] ?? []).map(([name, label]) => (
                        <Link
                            key={name}
                            href={route(name)}
                            className={`block rounded-md px-3 py-2 text-sm font-medium ${isActive(name) ? "bg-slate-800 text-white" : "hover:bg-slate-800/60 hover:text-white"}`}
                        >
                            {label}
                        </Link>
                    ))}
                </nav>
                <div className="border-t border-slate-800 px-4 py-3 text-xs text-slate-400">
                    Signed in as{" "}
                    <span className="font-medium text-slate-200">
                        {user?.name}
                    </span>
                    <span className="mt-1 block w-fit rounded bg-slate-800 px-2 py-0.5 text-[10px] uppercase tracking-wide">
                        {user?.role?.replaceAll("_", " ")}
                    </span>
                </div>
            </aside>
            <div className="flex min-w-0 flex-1 flex-col">
                <header className="flex items-center justify-between border-b bg-white px-6 py-4">
                    <h1 className="text-xl font-semibold text-slate-800">
                        {title}
                    </h1>
                    <div className="flex items-center gap-4 text-sm">
                        <Link
                            href={route("profile.edit")}
                            className="text-slate-600 hover:text-slate-900"
                        >
                            Profile
                        </Link>
                        <a
                            href="#"
                            onClick={logout}
                            className="text-slate-600 hover:text-slate-900"
                        >
                            Log out
                        </a>
                    </div>
                </header>
                <main className="flex-1 p-6">
                    {flash?.success && (
                        <div className="mb-4 rounded-md border border-green-200 bg-green-50 px-4 py-3 text-sm text-green-800">
                            {flash.success}
                        </div>
                    )}
                    {flash?.error && (
                        <div className="mb-4 rounded-md border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-800">
                            {flash.error}
                        </div>
                    )}
                    {children}
                </main>
            </div>
        </div>
    );
}

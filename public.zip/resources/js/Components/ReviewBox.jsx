import { useForm } from "@inertiajs/react";

export default function ReviewBox({ result, submitRoute }) {
    const { data, setData, post, processing } = useForm({
        review_note: result.review_note ?? "",
    });
    if (result.reviewed_at) {
        return (
            <div className="rounded-lg border border-emerald-200 bg-emerald-50 p-4">
                <p className="text-sm font-semibold text-emerald-800">
                    Reviewed
                </p>
                <p className="mt-1 text-sm text-emerald-700">
                    by {result.reviewer?.name ?? "Unknown"} on{" "}
                    {new Date(result.reviewed_at).toLocaleString()}
                </p>
                {result.review_note && (
                    <p className="mt-2 whitespace-pre-line text-sm text-emerald-900">
                        {result.review_note}
                    </p>
                )}
            </div>
        );
    }
    return (
        <form
            onSubmit={(e) => {
                e.preventDefault();
                post(route(submitRoute, result.id));
            }}
            className="rounded-lg border bg-white p-4 shadow-sm"
        >
            <h3 className="mb-2 font-semibold text-slate-800">
                Review this record
            </h3>
            <textarea
                value={data.review_note}
                onChange={(e) => setData("review_note", e.target.value)}
                rows={4}
                placeholder="Optional review note explaining the examination outcome…"
                className="w-full rounded-md border-gray-300 text-sm shadow-sm"
            />
            <button
                disabled={processing}
                className="mt-3 rounded-md bg-slate-800 px-4 py-2 text-sm font-medium text-white disabled:opacity-50"
            >
                Mark as Reviewed
            </button>
        </form>
    );
}

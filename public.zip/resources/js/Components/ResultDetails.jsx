import StatusBadge from './StatusBadge';
const Row = ({ k, v }) => <div className="flex justify-between border-b py-2 text-sm"><dt className="text-gray-500">{k}</dt><dd className="font-medium">{v ?? '—'}</dd></div>;
const Card = ({ title, children }) => <section className="rounded-lg border bg-white p-5"><h3 className="mb-2 font-semibold">{title}</h3><dl>{children}</dl></section>;
export default function ResultDetails({ result }) {
    const pu = result.polling_unit ?? {}, el = result.election ?? {}, cands = result.candidate_results ?? {};
    return (
        <div className="grid gap-4 lg:grid-cols-2">
            <Card title="Polling unit">
                <Row k="Name" v={pu.name} /><Row k="Code" v={pu.code} /><Row k="LGA" v={pu.lga} /><Row k="Ward" v={pu.ward} />
                <Row k="Election" v={`${el.year} ${el.type} (${el.state})`} />
            </Card>
            <Card title="Voters and results">
                <Row k="Registered voters" v={result.registered_voters} />
                <Row k="Accredited voters" v={result.accredited_voters} />
                {Object.entries(cands).map(([k, v]) => <Row key={k} k={k.toUpperCase()} v={v} />)}
                <Row k="Rejected votes" v={result.rejected_votes} /><Row k="Total votes" v={result.total_votes} />
            </Card>
            <section className="rounded-lg border bg-white p-5 lg:col-span-2">
                <div className="mb-3 flex items-center gap-3"><h3 className="font-semibold">Validation</h3><StatusBadge status={result.validation_status} /></div>
                <ul className="space-y-2 text-sm">
                    {result.validation_results?.map((v) => (
                        <li key={v.id} className="rounded border bg-gray-50 p-3">
                            <div className="font-mono text-xs text-gray-500">{v.validation_rule}</div>
                            <div>{v.validation_message}</div>
                            <div className="text-xs text-gray-400">Checked {v.checked_at ? new Date(v.checked_at).toLocaleString() : '—'}</div>
                        </li>
                    ))}
                </ul>
                <p className="mt-3 text-xs text-gray-500">A validation status describes data consistency only. It does not establish whether an election event was accurate or fair.</p>
            </section>
        </div>
    );
}

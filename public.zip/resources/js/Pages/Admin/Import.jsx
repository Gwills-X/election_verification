import AppLayout from "../../Components/AppLayout";
import InputError from "../../Components/InputError";
import InputLabel from "../../Components/InputLabel";
import PrimaryButton from "../../Components/PrimaryButton";
import { Link, useForm } from "@inertiajs/react";

const sel = "mt-1 block w-full rounded-md border-gray-300 text-sm shadow-sm";

export default function Import({ elections, summary }) {
    const { data, setData, post, processing, errors, reset } = useForm({
        election_id: elections[0]?.id ?? "",
        dataset_type: "REAL",
        file: null,
    });
    const submit = (e) => {
        e.preventDefault();
        post(route("admin.import.store"), {
            forceFormData: true,
            onSuccess: () => reset("file"),
        });
    };
    return (
        <AppLayout title="Import Election Dataset">
            <form
                onSubmit={submit}
                className="max-w-2xl space-y-4 rounded-lg border bg-white p-6 shadow-sm"
            >
                <div>
                    <InputLabel value="Election" />
                    <select
                        className={sel}
                        value={data.election_id}
                        onChange={(e) => setData("election_id", e.target.value)}
                    >
                        {elections.map((e) => (
                            <option key={e.id} value={e.id}>
                                {e.name} ({e.status})
                            </option>
                        ))}
                    </select>
                    {elections.length === 0 && (
                        <p className="mt-1 text-xs text-red-600">
                            Create an election first.
                        </p>
                    )}
                    <InputError message={errors.election_id} />
                </div>
                <div>
                    <InputLabel value="Dataset type" />
                    <div className="mt-2 space-y-2 text-sm">
                        <label className="flex items-center gap-2">
                            <input
                                type="radio"
                                checked={data.dataset_type === "REAL"}
                                onChange={() => setData("dataset_type", "REAL")}
                            />{" "}
                            Real dataset (official figures)
                        </label>
                        <label className="flex items-center gap-2">
                            <input
                                type="radio"
                                checked={data.dataset_type === "SYNTHETIC"}
                                onChange={() =>
                                    setData("dataset_type", "SYNTHETIC")
                                }
                            />{" "}
                            Synthetic / test dataset (clearly labelled test
                            records such as TEST-001)
                        </label>
                    </div>
                    <InputError message={errors.dataset_type} />
                </div>
                <div>
                    <InputLabel value="CSV file" />
                    <input
                        type="file"
                        accept=".csv,.txt"
                        onChange={(e) => setData("file", e.target.files[0])}
                        className="mt-1 block w-full text-sm text-gray-600 file:mr-4 file:rounded-md file:border-0 file:bg-slate-800 file:px-4 file:py-2 file:text-sm file:font-medium file:text-white"
                    />
                    <p className="mt-1 text-xs text-gray-400">
                        Required columns: LGA, Ward, PU-Code. Candidate/party
                        columns are detected automatically. CSV, TSV, semicolon
                        or pipe separated.
                    </p>
                    <InputError message={errors.file} />
                </div>
                <PrimaryButton
                    disabled={
                        processing || elections.length === 0 || !data.file
                    }
                >
                    Upload &amp; Validate
                </PrimaryButton>
            </form>

            {summary && (
                <div className="mt-6 rounded-lg border bg-white p-6 shadow-sm">
                    <h3 className="mb-4 font-semibold text-slate-800">
                        Import Summary
                    </h3>
                    <div className="grid grid-cols-2 gap-4 sm:grid-cols-4 lg:grid-cols-7">
                        {[
                            ["Records found", summary.found, "text-slate-700"],
                            ["Imported", summary.imported, "text-slate-700"],
                            ["Valid", summary.valid, "text-green-600"],
                            ["Invalid", summary.invalid, "text-red-600"],
                            ["Flagged", summary.flagged, "text-amber-600"],
                            [
                                "Duplicates",
                                summary.duplicates,
                                "text-amber-600",
                            ],
                            ["Skipped", summary.skipped, "text-gray-500"],
                        ].map(([l, v, c]) => (
                            <div
                                key={l}
                                className="rounded-md border p-3 text-center"
                            >
                                <p className={`text-xl font-bold ${c}`}>{v}</p>
                                <p className="text-xs uppercase tracking-wide text-gray-500">
                                    {l}
                                </p>
                            </div>
                        ))}
                    </div>
                    <div className="mt-4">
                        <p className="text-xs font-semibold uppercase text-gray-500">
                            Candidate / party columns detected
                        </p>
                        <div className="mt-1 flex flex-wrap gap-1">
                            {summary.candidate_columns.map((c) => (
                                <span
                                    key={c}
                                    className="rounded bg-slate-100 px-2 py-0.5 text-xs font-medium text-slate-700"
                                >
                                    {c}
                                </span>
                            ))}
                            {summary.candidate_columns.length === 0 && (
                                <span className="text-xs text-gray-400">
                                    None detected
                                </span>
                            )}
                        </div>
                    </div>
                    {summary.rules_skipped.length > 0 && (
                        <div className="mt-4 rounded-md border border-amber-200 bg-amber-50 p-3 text-sm text-amber-800">
                            <p className="font-semibold">
                                Rules skipped (not applicable to this dataset):
                            </p>
                            <ul className="mt-1 list-inside list-disc">
                                {summary.rules_skipped.map((r) => (
                                    <li key={r}>{r}</li>
                                ))}
                            </ul>
                        </div>
                    )}
                    <Link
                        href={route("admin.flagged")}
                        className="mt-4 inline-block text-sm text-blue-700 hover:underline"
                    >
                        Review flagged records →
                    </Link>
                </div>
            )}
        </AppLayout>
    );
}

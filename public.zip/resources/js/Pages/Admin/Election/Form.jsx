import AppLayout from "../../../Components/AppLayout";
import InputError from "../../../Components/InputError";
import InputLabel from "../../../Components/InputLabel";
import TextInput from "../../../Components/TextInput";
import PrimaryButton from "../../../Components/PrimaryButton";
import { Link, useForm } from "@inertiajs/react";

const field = "mt-1 block w-full";
const lbl = "text-sm font-medium text-gray-700";

export default function Form({ election, types, statuses }) {
    const { data, setData, post, put, processing, errors } = useForm({
        name: election?.name ?? "",
        year: election?.year ?? new Date().getFullYear(),
        type: election?.type ?? "",
        state: election?.state ?? "",
        election_date: election?.election_date?.slice(0, 10) ?? "",
        status: election?.status ?? "DRAFT",
        description: election?.description ?? "",
    });
    const submit = (e) => {
        e.preventDefault();
        election
            ? put(route("admin.elections.update", election.id))
            : post(route("admin.elections.store"));
    };
    return (
        <AppLayout title={election ? "Edit Election" : "Create Election"}>
            <form
                onSubmit={submit}
                className="max-w-2xl space-y-4 rounded-lg border bg-white p-6 shadow-sm"
            >
                <div>
                    <InputLabel value="Election name" className={lbl} />
                    <TextInput
                        className={field}
                        value={data.name}
                        onChange={(e) => setData("name", e.target.value)}
                    />
                    <InputError message={errors.name} />
                </div>
                <div className="grid gap-4 sm:grid-cols-3">
                    <div>
                        <InputLabel value="Year" className={lbl} />
                        <TextInput
                            type="number"
                            className={field}
                            value={data.year}
                            onChange={(e) => setData("year", e.target.value)}
                        />
                        <InputError message={errors.year} />
                    </div>
                    <div>
                        <InputLabel value="Type" className={lbl} />
                        <TextInput
                            list="election-types"
                            className={field}
                            value={data.type}
                            onChange={(e) => setData("type", e.target.value)}
                        />
                        <datalist id="election-types">
                            {types.map((t) => (
                                <option key={t} value={t} />
                            ))}
                        </datalist>
                        <InputError message={errors.type} />
                    </div>
                    <div>
                        <InputLabel value="State" className={lbl} />
                        <TextInput
                            className={field}
                            value={data.state}
                            onChange={(e) => setData("state", e.target.value)}
                        />
                        <InputError message={errors.state} />
                    </div>
                </div>
                <div className="grid gap-4 sm:grid-cols-2">
                    <div>
                        <InputLabel value="Election date" className={lbl} />
                        <TextInput
                            type="date"
                            className={field}
                            value={data.election_date}
                            onChange={(e) =>
                                setData("election_date", e.target.value)
                            }
                        />
                        <InputError message={errors.election_date} />
                    </div>
                    <div>
                        <InputLabel value="Status" className={lbl} />
                        <select
                            className={
                                field +
                                " rounded-md border-gray-300 text-sm shadow-sm"
                            }
                            value={data.status}
                            onChange={(e) => setData("status", e.target.value)}
                        >
                            {statuses.map((s) => (
                                <option key={s}>{s}</option>
                            ))}
                        </select>
                        <InputError message={errors.status} />
                    </div>
                </div>
                <div>
                    <InputLabel value="Description" className={lbl} />
                    <textarea
                        rows={4}
                        className={
                            field +
                            " rounded-md border-gray-300 text-sm shadow-sm"
                        }
                        value={data.description}
                        onChange={(e) => setData("description", e.target.value)}
                    />
                    <InputError message={errors.description} />
                </div>
                <div className="flex gap-3">
                    <PrimaryButton disabled={processing}>
                        {election ? "Save changes" : "Create election"}
                    </PrimaryButton>
                    <Link
                        href={route("admin.elections.index")}
                        className="rounded-md border px-4 py-2 text-sm"
                    >
                        Cancel
                    </Link>
                </div>
            </form>
        </AppLayout>
    );
}

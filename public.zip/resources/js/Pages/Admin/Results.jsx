import AppLayout from "../../Components/AppLayout";
import ResultFilters from "../../Components/ResultFilters";
import ResultsTable from "../../Components/ResultsTable";
import Pagination from "../../Components/Pagination";

export default function Results({
    title = "Result Records",
    routeName = "admin.results",
    results,
    filters,
    elections,
    states,
    lgas,
    wards,
}) {
    return (
        <AppLayout title={title}>
            <ResultFilters
                routeName={routeName}
                filters={filters}
                fields={[
                    "q",
                    "election_id",
                    "state",
                    "lga",
                    "ward",
                    "status",
                    "review",
                ]}
                options={{ elections, states, lgas, wards }}
            />
            <ResultsTable results={results} linkPrefix="admin.results" />
            <Pagination links={results.links} />
        </AppLayout>
    );
}

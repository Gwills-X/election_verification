import AppLayout from "../../Components/AppLayout";
import ResultFilters from "../../Components/ResultFilters";
import ResultsTable from "../../Components/ResultsTable";
import Pagination from "../../Components/Pagination";

export default function Results({ results, filters, lgas, wards }) {
    return (
        <AppLayout title="Result Records">
            <ResultFilters
                routeName="officer.results"
                filters={filters}
                fields={["q", "lga", "ward", "status", "review"]}
                options={{ lgas, wards }}
            />
            <ResultsTable results={results} linkPrefix="officer.results" />
            <Pagination links={results.links} />
        </AppLayout>
    );
}

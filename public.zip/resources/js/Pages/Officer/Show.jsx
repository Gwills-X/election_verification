import { Link } from "@inertiajs/react";
import AppLayout from "../../Components/AppLayout";
import ResultInfo from "../../Components/ResultInfo";
import ReviewBox from "../../Components/ReviewBox";

export default function Show({ result }) {
    return (
        <AppLayout
            title={`Review ${result.polling_unit?.code ?? "#" + result.id}`}
        >
            <Link
                href={route("officer.queue")}
                className="text-sm text-blue-700 hover:underline"
            >
                ← Back to review queue
            </Link>
            <div className="mt-4 grid gap-6 lg:grid-cols-3">
                <div className="lg:col-span-2">
                    <ResultInfo result={result} />
                </div>
                <div>
                    <ReviewBox
                        result={result}
                        submitRoute="officer.results.review"
                    />
                </div>
            </div>
        </AppLayout>
    );
}

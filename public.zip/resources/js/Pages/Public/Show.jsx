import { Link } from "@inertiajs/react";
import PublicLayout from "../../Components/PublicLayout";
import ResultInfo from "../../Components/ResultInfo";

export default function Show({ result }) {
    return (
        <PublicLayout>
            <Link
                href={route("verify.index", {
                    election_id: result.election_id,
                })}
                className="text-sm text-blue-700 hover:underline"
            >
                ← Back to search
            </Link>
            <h1 className="mb-6 mt-2 text-2xl font-bold text-slate-800">
                Polling-Unit Result
            </h1>
            <ResultInfo result={result} />
            {result.reviewed_at && (
                <div className="mt-6 rounded-lg border border-emerald-200 bg-emerald-50 p-4 text-sm">
                    <p className="font-semibold text-emerald-800">
                        Reviewed by an authorised officer
                    </p>
                    <p className="mt-1 text-emerald-700">
                        on {new Date(result.reviewed_at).toLocaleString()}
                    </p>
                    {result.review_note && (
                        <p className="mt-2 whitespace-pre-line text-emerald-900">
                            {result.review_note}
                        </p>
                    )}
                </div>
            )}
        </PublicLayout>
    );
}

<?php
namespace App\Http\Requests\Admin;
use Illuminate\Foundation\Http\FormRequest;
class UpdateElectionRequest extends FormRequest
{
    public function authorize(): bool { return true; }
    public function rules(): array
    {
        return [
            'name' => ['required', 'string', 'max:255'],
            'year' => ['required', 'integer', 'min:1998', 'max:2100'],
            'type' => ['required', 'string', 'max:100'],
            'state' => ['required', 'string', 'max:100'],
            'election_date' => ['nullable', 'date'],
            'description' => ['nullable', 'string', 'max:5000'],
            'status' => ['required', 'in:DRAFT,ACTIVE,COMPLETED,ARCHIVED'],
        ];
    }
}

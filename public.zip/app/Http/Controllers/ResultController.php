<?php
namespace App\Http\Controllers;
use App\Models\ElectionResult;
use App\Models\PollingUnit;
use Illuminate\Http\Request;
use Inertia\Inertia;
class ResultController extends Controller
{
    public function index(Request $request)
    {
        $f = $request->only('q', 'lga', 'ward', 'status');
        return Inertia::render('Results/Index', [
            'results' => ElectionResult::with('pollingUnit')->filter($f)->latest('id')->paginate(20)->withQueryString(),
            'filters' => $f,
            'lgas' => PollingUnit::whereNotNull('lga')->distinct()->orderBy('lga')->pluck('lga'),
            'wards' => PollingUnit::whereNotNull('ward')->distinct()->orderBy('ward')->pluck('ward'),
        ]);
    }

    public function show(ElectionResult $result)
    {
        return Inertia::render('Results/Show', ['result' => $result->load('pollingUnit', 'election', 'validationResults')]);
    }
}

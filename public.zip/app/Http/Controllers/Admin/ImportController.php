<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use App\Http\Requests\ImportResultRequest;
use App\Models\Election;
use App\Services\AuditLogService;
use App\Services\ResultImportService;
use Inertia\Inertia;
use InvalidArgumentException;
use Throwable;
class ImportController extends Controller
{
    public function index()
    {
        return Inertia::render('Admin/Import', ['summary' => session('summary')]);
    }

    public function store(ImportResultRequest $request, ResultImportService $importer, AuditLogService $audit)
    {
        $election = Election::firstOrCreate(
            $request->only('year', 'type', 'state'), ['status' => 'active']);
        $audit->log($request->user()->id, 'DATASET_UPLOADED', "Uploaded {$request->file('file')->getClientOriginalName()}");
        try {
            $summary = $importer->import($request->file('file')->getRealPath(), $election);
        } catch (InvalidArgumentException $e) {
            return back()->withErrors(['file' => $e->getMessage()]);
        } catch (Throwable $e) {
            report($e);
            return back()->withErrors(['file' => 'The import failed unexpectedly. No records were saved.']);
        }
        $audit->log($request->user()->id, 'VALIDATION_EXECUTED',
            "Imported {$summary['imported']} of {$summary['found']} records for {$election->year} {$election->type} ({$election->state}).");
        return redirect()->route('admin.import')->with('summary', $summary);
    }
}

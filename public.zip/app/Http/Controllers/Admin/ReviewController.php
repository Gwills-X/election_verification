<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use App\Models\ElectionResult;
use App\Models\PollingUnit;
use App\Services\AuditLogService;
use Illuminate\Http\Request;
use Inertia\Inertia;
class ReviewController extends Controller
{
    public function results(Request $r) { return $this->list($r, 'All results', null); }
    public function flagged(Request $r) { return $this->list($r, 'Flagged records', 'FLAGGED_FOR_REVIEW'); }

    private function list(Request $request, string $title, ?string $forced)
    {
        $f = $request->only('q', 'lga', 'ward', 'status');
        if ($forced) $f['status'] = $forced;
        return Inertia::render('Admin/Results', [
            'title' => $title,
            'routeName' => $forced ? 'admin.flagged' : 'admin.results',
            'results' => ElectionResult::with('pollingUnit')->filter($f)->latest('id')->paginate(20)->withQueryString(),
            'filters' => $f,
            'lgas' => PollingUnit::whereNotNull('lga')->distinct()->orderBy('lga')->pluck('lga'),
            'wards' => PollingUnit::whereNotNull('ward')->distinct()->orderBy('ward')->pluck('ward'),
        ]);
    }

    public function show(ElectionResult $result)
    {
        return Inertia::render('Admin/Show', [
            'result' => $result->load('pollingUnit', 'election', 'validationResults', 'reviewer:id,name'),
            'flash' => session('success'),
        ]);
    }

    public function review(Request $request, ElectionResult $result, AuditLogService $audit)
    {
        $data = $request->validate(['review_note' => ['nullable', 'string', 'max:2000']]);
        $result->update(['reviewed_at' => now(), 'reviewed_by' => $request->user()->id, 'review_note' => $data['review_note'] ?? null]);
        $audit->log($request->user()->id, 'RECORD_REVIEWED', "Marked result #{$result->id} as reviewed.");
        return back()->with('success', 'Record marked as reviewed.');
    }
}

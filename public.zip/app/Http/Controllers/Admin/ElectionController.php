<?php
namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StoreElectionRequest;
use App\Http\Requests\Admin\UpdateElectionRequest;
use App\Models\Election;
use App\Services\AuditLogService;
use Illuminate\Http\Request;
use Inertia\Inertia;

class ElectionController extends Controller
{
    public function index(Request $request)
    {
        return Inertia::render('Admin/Elections/Index', [
            'elections' => Election::withCount('results')->withCount('assignedOfficers')
                ->when($request->status, fn ($q, $v) => $q->where('status', $v))
                ->orderByDesc('year')->paginate(15)->withQueryString(),
            'filters' => $request->only('status'),
            'statuses' => Election::STATUSES,
        ]);
    }

    public function create()
    {
        return Inertia::render('Admin/Elections/Form', [
            'election' => null,
            'types' => config('elections.types'),
            'statuses' => Election::STATUSES,
        ]);
    }

    public function store(StoreElectionRequest $request, AuditLogService $audit)
    {
        $election = Election::create($request->validated());
        $audit->log($request->user()->id, 'ELECTION_CREATED', "Created election '{$election->name}'.");
        return redirect()->route('admin.elections.show', $election)->with('success', 'Election created.');
    }

    public function show(Election $election)
    {
        return Inertia::render('Admin/Elections/Show', [
            'election' => $election,
            'statusCounts' => $election->statusCounts(),
            'candidateTotals' => $election->candidateTotals(),
            'officers' => $election->assignedOfficers()->select('users.id', 'users.name', 'users.email')->get(),
            'imports' => $election->datasetImports()->with('user:id,name')->latest()->limit(5)->get(),
            'results' => $election->results()->with('pollingUnit:id,code,name,lga,ward')->latest('id')->paginate(10),
        ]);
    }

    public function edit(Election $election)
    {
        return Inertia::render('Admin/Elections/Form', [
            'election' => $election,
            'types' => config('elections.types'),
            'statuses' => Election::STATUSES,
        ]);
    }

    public function update(UpdateElectionRequest $request, Election $election, AuditLogService $audit)
    {
        $election->update($request->validated());
        $audit->log($request->user()->id, 'ELECTION_UPDATED', "Updated election '{$election->name}'.");
        return redirect()->route('admin.elections.show', $election)->with('success', 'Election updated.');
    }

    public function archive(Election $election, AuditLogService $audit)
    {
        $election->update(['status' => Election::STATUS_ARCHIVED]);
        $audit->log(request()->user()->id, 'ELECTION_ARCHIVED', "Archived election '{$election->name}'.");
        return back()->with('success', 'Election archived.');
    }

    public function destroy(Election $election, AuditLogService $audit)
    {
        if ($election->results()->exists()) {
            return back()->with('error', 'This election has result records and cannot be deleted. Archive it instead.');
        }
        $audit->log(request()->user()->id, 'ELECTION_DELETED', "Deleted election '{$election->name}'.");
        $election->delete();
        return redirect()->route('admin.elections.index')->with('success', 'Election deleted.');
    }
}

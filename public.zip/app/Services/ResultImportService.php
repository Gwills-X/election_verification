<?php

namespace App\Services;

use App\Models\DatasetImport;
use App\Models\Election;
use App\Models\ElectionResult;
use App\Models\PollingUnit;
use App\Models\ValidationResult;
use Illuminate\Support\Facades\DB;
use InvalidArgumentException;

class ResultImportService
{
    public const REQUIRED_HEADERS = ['polling_unit_code', 'lga', 'ward'];

    public const KNOWN = [
        'state', 'polling_unit_code', 'polling_unit_name', 'lga', 'ward',
        'registered_voters', 'accredited_voters', 'rejected_votes', 'total_votes',
        'results_found', 'transcription_count', 'result_sheet_stamped',
        'result_sheet_corrected', 'result_sheet_invalid', 'result_sheet_unclear',
        'result_sheet_unsigned', 'results_file',
    ];

    private const HEADER_ALIASES = [
        'state' => ['state', 'state name', 'state_name'],
        'polling_unit_code' => ['polling_unit_code', 'polling unit code', 'pollingunitcode', 'pu code', 'pu-code', 'pu_code', 'pucode', 'polling code', 'polling-code', 'polling_code', 'code'],
        'polling_unit_name' => ['polling_unit_name', 'polling unit name', 'pollingunitname', 'pu name', 'pu-name', 'pu_name', 'puname', 'polling name', 'polling_name', 'name'],
        'lga' => ['lga', 'local government', 'local government area', 'local_government', 'local_government_area', 'localgovernment', 'localgovernmentarea'],
        'ward' => ['ward', 'ward name', 'ward_name', 'wardname'],
        'registered_voters' => ['registered_voters', 'registered voters', 'registeredvoters', 'registered voter', 'registered_voter', 'reg voters', 'reg_voters', 'regvoters'],
        'accredited_voters' => ['accredited_voters', 'accredited voters', 'accreditedvoters', 'accredited voter', 'accredited_voter', 'accredited'],
        'rejected_votes' => ['rejected_votes', 'rejected votes', 'rejectedvotes', 'rejected vote', 'rejected_vote', 'rejected'],
        'total_votes' => ['total_votes', 'total votes', 'totalvotes', 'total vote', 'total_vote', 'total valid votes', 'total_valid_votes', 'total valid'],
        'results_found' => ['results_found', 'results found', 'resultsfound'],
        'transcription_count' => ['transcription_count', 'transcription count', 'transcriptioncount'],
        'result_sheet_stamped' => ['result_sheet_stamped', 'result sheet stamped', 'resultsheetstamped'],
        'result_sheet_corrected' => ['result_sheet_corrected', 'result sheet corrected', 'resultsheetcorrected'],
        'result_sheet_invalid' => ['result_sheet_invalid', 'result sheet invalid', 'resultsheetinvalid'],
        'result_sheet_unclear' => ['result_sheet_unclear', 'result sheet unclear', 'resultsheetunclear'],
        'result_sheet_unsigned' => ['result_sheet_unsigned', 'result sheet unsigned', 'resultsheetunsigned'],
        'results_file' => ['results_file', 'results file', 'resultsfile', 'result file', 'results link', 'results_link', 'results url', 'results_url'],
    ];

    /**
     * Import a polling-unit dataset for an election.
     *
     * @return array Import summary shown to the user.
     */
    public function import(string $path, Election $election, string $datasetType = DatasetImport::TYPE_REAL, ?int $userId = null): array
    {
        if (!is_readable($path)) {
            throw new InvalidArgumentException('The election result file could not be read.');
        }

        $handle = fopen($path, 'r');
        if (!$handle) {
            throw new InvalidArgumentException('The election result file could not be opened.');
        }

        $delimiter = $this->detectDelimiter($handle);
        rewind($handle);

        $rawHeaders = fgetcsv($handle, 0, $delimiter);
        if (!$rawHeaders || $rawHeaders === [null]) {
            fclose($handle);
            throw new InvalidArgumentException('The file is empty or does not contain a header row.');
        }

        $normalizedHeaders = $this->normalizeHeaders($rawHeaders);

        $missing = array_diff(self::REQUIRED_HEADERS, $normalizedHeaders);
        if ($missing) {
            fclose($handle);
            throw new InvalidArgumentException(
                'Missing required column(s): ' . implode(', ', $missing) .
                '. Detected columns: ' . implode(', ', $normalizedHeaders) .
                '. Expected examples include State, LGA, Ward, PU-Code, PU-Name.'
            );
        }

        $candidateColumns = array_values(array_diff($normalizedHeaders, self::KNOWN));

        $rows = [];
        $malformed = 0;
        while (($csvRow = fgetcsv($handle, 0, $delimiter)) !== false) {
            $hasValue = false;
            foreach ($csvRow as $value) {
                if (trim((string) $value) !== '') { $hasValue = true; break; }
            }
            if (!$hasValue) continue;
            if (count($csvRow) !== count($normalizedHeaders)) { $malformed++; continue; }
            $rows[] = array_combine($normalizedHeaders, array_map(fn ($v) => trim((string) $v), $csvRow));
        }
        fclose($handle);

        if (!$rows && !$malformed) {
            throw new InvalidArgumentException('The file contains no data rows.');
        }

        $codes = array_filter(array_column($rows, 'polling_unit_code'), fn ($c) => trim((string) $c) !== '');
        $counts = array_count_values($codes);

        $hasAccredited = in_array('accredited_voters', $normalizedHeaders, true);
        $hasRegistered = in_array('registered_voters', $normalizedHeaders, true);
        $hasRejected = in_array('rejected_votes', $normalizedHeaders, true);
        $hasTotalVotes = in_array('total_votes', $normalizedHeaders, true);

        $validator = new ResultValidationService(
            candidateColumns: $candidateColumns,
            requiredFields: self::REQUIRED_HEADERS,
            hasAccredited: $hasAccredited,
            hasRegistered: $hasRegistered,
            hasRejected: $hasRejected,
            hasTotalVotes: $hasTotalVotes,
        );

        $import = DatasetImport::create([
            'election_id' => $election->id,
            'user_id' => $userId,
            'filename' => basename($path),
            'dataset_type' => $datasetType,
        ]);

        return DB::transaction(function () use (
            $rows, $malformed, $counts, $validator, $election, $import,
            $candidateColumns, $hasAccredited, $hasTotalVotes
        ) {
            $summary = [
                'import_id' => $import->id,
                'found' => count($rows) + $malformed,
                'imported' => 0,
                'valid' => 0,
                'invalid' => 0,
                'flagged' => 0,
                'duplicates' => 0,
                'skipped' => $malformed,
                'candidate_columns' => $candidateColumns,
                'rules_skipped' => [],
            ];

            if (!$hasAccredited) $summary['rules_skipped'][] = 'Accredited-voter check was skipped because the dataset has no accredited_voters column.';
            if (!$hasTotalVotes) $summary['rules_skipped'][] = 'Total-votes comparison was skipped because the dataset has no total_votes column.';
            if (!$candidateColumns) $summary['rules_skipped'][] = 'Candidate-total check was skipped because no candidate/party columns were detected.';

            foreach ($rows as $row) {
                $code = trim((string) ($row['polling_unit_code'] ?? ''));
                if ($code === '') { $summary['skipped']++; continue; }

                $duplicateInFile = ($counts[$code] ?? 0) > 1;
                $duplicateInDb = ElectionResult::where('election_id', $election->id)
                    ->whereHas('pollingUnit', fn ($q) => $q->where('code', $code))->exists();

                if ($duplicateInFile || $duplicateInDb) $summary['duplicates']++;

                $outcome = $validator->validate($row, $duplicateInFile, $duplicateInDb);

                $pollingUnit = PollingUnit::firstOrCreate(
                    ['code' => $code],
                    [
                        'state' => $this->nullableString($row['state'] ?? null),
                        'lga' => $this->nullableString($row['lga'] ?? null),
                        'ward' => $this->nullableString($row['ward'] ?? null),
                        'name' => $this->nullableString($row['polling_unit_name'] ?? null),
                    ]
                );

                $updates = [];
                foreach (['state' => 'state', 'lga' => 'lga', 'ward' => 'ward'] as $col => $key) {
                    if (!$pollingUnit->{$col} && !empty($row[$key])) $updates[$col] = $row[$key];
                }
                if (!$pollingUnit->name && !empty($row['polling_unit_name'] ?? null)) $updates['name'] = $row['polling_unit_name'];
                if ($updates) $pollingUnit->update($updates);

                $candidateResults = [];
                foreach ($candidateColumns as $candidate) {
                    $value = $row[$candidate] ?? null;
                    $candidateResults[$candidate] = trim((string) $value) === '' ? null : $value;
                }

                $result = ElectionResult::create([
                    'election_id' => $election->id,
                    'polling_unit_id' => $pollingUnit->id,
                    'registered_voters' => $this->integerValue($row['registered_voters'] ?? null),
                    'accredited_voters' => $this->integerValue($row['accredited_voters'] ?? null),
                    'candidate_results' => $candidateResults,
                    'rejected_votes' => $this->integerValue($row['rejected_votes'] ?? null),
                    'total_votes' => $this->integerValue($row['total_votes'] ?? null),
                    'validation_status' => $outcome['status'],
                    'source_type' => $import->dataset_type,
                    'dataset_import_id' => $import->id,
                ]);

                $actionable = array_filter($outcome['violations'], fn ($v) =>
                    in_array($v['severity'], [ResultValidationService::INVALID, ResultValidationService::FLAGGED], true));

                if (!$actionable) {
                    ValidationResult::create([
                        'election_result_id' => $result->id,
                        'status' => ResultValidationService::VALID,
                        'validation_rule' => 'ALL_RULES',
                        'validation_message' => 'All applicable validation rules passed.',
                        'checked_at' => now(),
                    ]);
                }

                foreach ($outcome['violations'] as $violation) {
                    ValidationResult::create([
                        'election_result_id' => $result->id,
                        'status' => $violation['severity'],
                        'validation_rule' => $violation['rule'],
                        'validation_message' => $violation['message'],
                        'checked_at' => now(),
                    ]);
                }

                $summary['imported']++;
                match ($outcome['status']) {
                    ResultValidationService::VALID => $summary['valid']++,
                    ResultValidationService::INVALID => $summary['invalid']++,
                    ResultValidationService::FLAGGED => $summary['flagged']++,
                    default => null,
                };
            }

            $import->update([
                'records_found' => $summary['found'],
                'records_imported' => $summary['imported'],
                'valid' => $summary['valid'],
                'invalid' => $summary['invalid'],
                'flagged' => $summary['flagged'],
                'duplicates' => $summary['duplicates'],
                'skipped' => $summary['skipped'],
                'candidate_columns' => $summary['candidate_columns'],
                'rules_skipped' => $summary['rules_skipped'],
            ]);

            return $summary;
        });
    }

    private function detectDelimiter($handle): string
    {
        $position = ftell($handle);
        $firstLine = fgets($handle);
        fseek($handle, $position);
        if ($firstLine === false) return ',';
        $delimiters = [',' => substr_count($firstLine, ','), "\t" => substr_count($firstLine, "\t"),
                       ';' => substr_count($firstLine, ';'), '|' => substr_count($firstLine, '|')];
        arsort($delimiters);
        $delimiter = array_key_first($delimiters);
        return ($delimiter === null || $delimiters[$delimiter] === 0) ? ',' : $delimiter;
    }

    private function normalizeHeaders(array $headers): array
    {
        $result = [];
        foreach ($headers as $header) {
            $original = trim(preg_replace('/^\xEF\xBB\xBF/', '', (string) $header));
            $normalized = $this->normalizeHeaderText($original);
            $mapped = null;
            foreach (self::HEADER_ALIASES as $applicationName => $aliases) {
                foreach ($aliases as $alias) {
                    if ($normalized === $this->normalizeHeaderText($alias)) { $mapped = $applicationName; break 2; }
                }
            }
            $result[] = $mapped ?? $this->cleanCandidateHeader($original);
        }
        if (count($result) !== count(array_unique($result))) {
            throw new InvalidArgumentException('The CSV contains duplicate or conflicting column names after normalization.');
        }
        return $result;
    }

    private function normalizeHeaderText(string $value): string
    {
        return preg_replace('/[^a-z0-9]+/', '', strtolower(trim($value)));
    }

    private function cleanCandidateHeader(string $header): string
    {
        return preg_replace('/^\xEF\xBB\xBF/', '', trim($header));
    }

    private function integerValue($value): ?int
    {
        if ($value === null || trim((string) $value) === '') return null;
        if (!is_numeric($value) || (float) $value != (int) $value) return null;
        return (int) $value;
    }

    private function nullableString($value): ?string
    {
        return ($value === null || trim((string) $value) === '') ? null : trim((string) $value);
    }
}

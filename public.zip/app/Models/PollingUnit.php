<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class PollingUnit extends Model
{
    protected $guarded = [];
    public function results() { return $this->hasMany(ElectionResult::class); }
}

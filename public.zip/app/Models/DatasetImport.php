<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DatasetImport extends Model
{
    public const TYPE_REAL = 'REAL';
    public const TYPE_SYNTHETIC = 'SYNTHETIC';
    public const TYPES = [self::TYPE_REAL, self::TYPE_SYNTHETIC];

    protected $guarded = [];
    protected $casts = ['candidate_columns' => 'array', 'rules_skipped' => 'array'];

    public function election() { return $this->belongsTo(Election::class); }
    public function user() { return $this->belongsTo(User::class); }
    public function results() { return $this->hasMany(ElectionResult::class); }
}

<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;

class ElectionResult extends Model
{
    protected $guarded = [];
    protected $casts = ['candidate_results' => 'array', 'reviewed_at' => 'datetime'];

    public function election() { return $this->belongsTo(Election::class); }
    public function pollingUnit() { return $this->belongsTo(PollingUnit::class); }
    public function validationResults() { return $this->hasMany(ValidationResult::class); }
    public function reviewer() { return $this->belongsTo(User::class, 'reviewed_by'); }
    public function datasetImport() { return $this->belongsTo(DatasetImport::class); }

    public function scopeFilter(Builder $q, array $f): Builder
    {
        return $q
            ->when($f['q'] ?? null, fn ($q, $v) => $q->whereHas('pollingUnit', fn ($p) => $p->where('code', 'like', "%{$v}%")->orWhere('name', 'like', "%{$v}%")))
            ->when($f['election_id'] ?? null, fn ($q, $v) => $q->where('election_id', $v))
            ->when($f['state'] ?? null, fn ($q, $v) => $q->whereHas('pollingUnit', fn ($p) => $p->where('state', $v)))
            ->when($f['lga'] ?? null, fn ($q, $v) => $q->whereHas('pollingUnit', fn ($p) => $p->where('lga', $v)))
            ->when($f['ward'] ?? null, fn ($q, $v) => $q->whereHas('pollingUnit', fn ($p) => $p->where('ward', $v)))
            ->when($f['status'] ?? null, fn ($q, $v) => $q->where('validation_status', $v))
            ->when(($f['review'] ?? null) === 'reviewed', fn ($q) => $q->whereNotNull('reviewed_at'))
            ->when(($f['review'] ?? null) === 'unreviewed', fn ($q) => $q->whereNull('reviewed_at'));
    }

    public static function statusCounts(): array
    {
        $c = static::selectRaw('validation_status, count(*) as n')->groupBy('validation_status')->pluck('n', 'validation_status');
        return ['total' => (int) $c->sum(), 'valid' => (int) ($c['VALID'] ?? 0), 'invalid' => (int) ($c['INVALID'] ?? 0),
                'flagged' => (int) ($c['FLAGGED_FOR_REVIEW'] ?? 0), 'pending' => (int) ($c['PENDING'] ?? 0)];
    }

    public static function candidateTotals(?int $electionId = null): array
    {
        $totals = [];
        $rows = static::query()->when($electionId, fn ($q, $v) => $q->where('election_id', $v))->pluck('candidate_results');
        foreach ($rows as $row) {
            foreach ((array) $row as $col => $votes) {
                if ($votes === null || $votes === '') continue;
                $totals[$col] = ($totals[$col] ?? 0) + (int) $votes;
            }
        }
        arsort($totals);
        return $totals;
    }
}

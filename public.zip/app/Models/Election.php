<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;

class Election extends Model
{
    public const STATUS_DRAFT = 'DRAFT';
    public const STATUS_ACTIVE = 'ACTIVE';
    public const STATUS_COMPLETED = 'COMPLETED';
    public const STATUS_ARCHIVED = 'ARCHIVED';

    public const STATUSES = [self::STATUS_DRAFT, self::STATUS_ACTIVE, self::STATUS_COMPLETED, self::STATUS_ARCHIVED];

    protected $guarded = [];
    protected $casts = ['election_date' => 'date'];

    public function results() { return $this->hasMany(ElectionResult::class); }
    public function datasetImports() { return $this->hasMany(DatasetImport::class); }
    public function assignedOfficers() { return $this->belongsToMany(User::class, 'election_user')->withTimestamps(); }

    public function isEditable(): bool
    {
        return in_array($this->status, [self::STATUS_DRAFT, self::STATUS_ACTIVE], true);
    }

    public function scopePubliclyVisible(Builder $q): Builder
    {
        return $q->whereIn('status', [self::STATUS_ACTIVE, self::STATUS_COMPLETED]);
    }

    public function statusCounts(): array
    {
        $c = $this->results()->selectRaw('validation_status, count(*) as n')->groupBy('validation_status')->pluck('n', 'validation_status');
        return ['total' => (int) $c->sum(), 'valid' => (int) ($c['VALID'] ?? 0), 'invalid' => (int) ($c['INVALID'] ?? 0),
                'flagged' => (int) ($c['FLAGGED_FOR_REVIEW'] ?? 0), 'pending' => (int) ($c['PENDING'] ?? 0)];
    }

    public function candidateTotals(): array
    {
        $totals = [];
        foreach ($this->results()->pluck('candidate_results') as $row) {
            foreach ((array) $row as $col => $votes) {
                if ($votes === null || $votes === '') continue;
                $totals[$col] = ($totals[$col] ?? 0) + (int) $votes;
            }
        }
        arsort($totals);
        return $totals;
    }
}

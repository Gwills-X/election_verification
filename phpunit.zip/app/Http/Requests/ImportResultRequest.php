<?php
namespace App\Http\Requests;
use Illuminate\Foundation\Http\FormRequest;
class ImportResultRequest extends FormRequest
{
    public function authorize(): bool { return true; }
    public function rules(): array
    {
        return [
            'election_id' => ['required', 'exists:elections,id'],
            'dataset_type' => ['required', 'in:REAL,SYNTHETIC'],
            'file' => ['required', 'file', 'mimes:csv,txt', 'max:51200'],
        ];
    }
}
